package mirim.hs.kr;

public class CategoryDAO {

}
