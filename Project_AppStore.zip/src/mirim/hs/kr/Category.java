package mirim.hs.kr;

public class Category {
	String category;
	int cnt;
}
